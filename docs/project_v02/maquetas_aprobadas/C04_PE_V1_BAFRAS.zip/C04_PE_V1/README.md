# C04 PE V1 — Prototipo de revisión, NO PUBLICABLE

- `proyectos-experiencia.html`: índice PE-01 a PE-04, textos exactos de D03 V1.20. Las seis referencias son **candidatas**; no se enlazan a fichas.
- `plantilla-ficha-proyecto.html`: plantilla estructural genérica con campos entre corchetes. No corresponde a un proyecto real.
- Las tarjetas de ejemplo son para validación de diseño, no habilitan publicación.
- El logotipo es tipográfico provisional. Los enlaces globales fuera del paquete son destinos futuros.
- Las etiquetas PE-02/03/04 y el aviso de maqueta son internas y se retirarán en producción.
- No se ha intervenido en código productivo ni se ha completado G1.
