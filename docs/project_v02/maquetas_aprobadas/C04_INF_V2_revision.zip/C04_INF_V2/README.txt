BAFRAS C04 Infraestructuras v2
Abrir infraestructuras_v2.html en un navegador local.
Los enlaces a otras páginas son demostrativos.
La selección de R18 se mantiene.
El Documento 05 v3.1 recoge decisiones y pendientes.
