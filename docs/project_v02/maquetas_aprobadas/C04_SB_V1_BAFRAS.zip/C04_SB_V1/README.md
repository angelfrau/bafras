# C04-SB-V1 · Sobre BAFRAS

Maqueta para revisión, no publicable. Copy de SB-01 a SB-05 reproducido de D03 V1.20. Fichas de fundadores: campos editoriales propuestos, sin datos completos ni fotografías verificadas. Enlaces de navegación previstos para implementación posterior. Captura de escritorio disponible; otras resoluciones pendientes de verificación.
